/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

/**
 *
 * @author acer
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("Nama    : Tio Restu Pambudi");
        System.out.println("NPM     : 2440506076");
        System.out.println("Alamat  : Beda,Mangansaka,Ke.Daka,Kab.Magelang");
        System.out.println("No Telp : 088221142042");
    }
}
